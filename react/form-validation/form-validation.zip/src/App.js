import { UserForm } from "./components/UserForm";

function App() {
  return (
    <div className="App">
      <UserForm></UserForm>
    </div>
  );
}

export default App;
