import { Component } from 'react';

export class Subcontent extends Component {

    render() {
        return(
            <div class="sub-content"></div>
        )
    }
}

export default Subcontent;