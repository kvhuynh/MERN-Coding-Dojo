import { Component } from 'react';

export class Navigation extends Component {

    render() {
        return(
            <div class="side-nav"></div>
        )
    }
}

export default Navigation;