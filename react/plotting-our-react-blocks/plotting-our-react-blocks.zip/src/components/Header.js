import { Component } from 'react';

export class Header extends Component {

    render() {
        return(
            <div class="top-nav"></div>
        )
    }
}

export default Header;