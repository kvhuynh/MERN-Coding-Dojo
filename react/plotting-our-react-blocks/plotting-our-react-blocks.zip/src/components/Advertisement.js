import { Component } from 'react';

export class Advertisement extends Component {

    render() {
        return(
            <div id="advertisement"></div>
        )
    }
}

export default Advertisement;