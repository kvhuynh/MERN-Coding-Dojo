ninja1.sayName();
// ninja1.showStats();